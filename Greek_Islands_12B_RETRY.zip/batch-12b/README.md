# Greek Islands Batch 12B — terrain concepts

Nimos, Sesklio, Gavdopoula, Kandelioussa, Pergousa, Pachia. Six separated, alpha-matted PNGs from original generated sheet. This is an art-review pack, **not** approved geographically accurate landmass overlays. The generator returned a baked-in checkerboard, so alpha-cleanup needs print review. Source sheet retained. No invented medieval forts.
