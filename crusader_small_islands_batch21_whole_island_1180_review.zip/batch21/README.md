# Crusader Map — Batch 21: Whole-island 1180 review sprites

**Sites:** Folegandros, Anafi, Astypalaia, Nisyros. Four separate transparent RGBA PNGs.

- Camera: elevated, from geographical south toward north (artistic intention; verify against the base map).
- Small-island rule: entire outline illustrated and principal settlement exaggerated for atlas legibility.
- All artwork is **provisional**: do not automatically supersede approved assets or claim exact coastline registration.
- Existing repo assets remain as alternatives. Geographic bounding boxes are copied from `assets/islands.json` for review. They are geographic envelopes, not proven pixel-accurate alignment.
- No later Venetian/Hospitaller castle complexes intended; all historical architecture is reconstructive and subject to expert review.
- Source image has genuine RGBA alpha. Cutouts use connected-component alpha masks to avoid adjacent paintings; detached visible rocks kept with their islands.
- `alpha_preview_dark.jpg` helps identify stray foreground pixels. `placement_manifest.json` records each candidate, source placement and SHA-256 checksum.

### Historical QA notes
- **Folegandros:** Early settlement at Palaiokastro; avoid representing post-Byzantine Kastro as 1180-built.
- **Anafi:** Byzantine settlement at Kastelli and conspicuous Kalamos massif; avoid later Venetian and monastery architecture.
- **Astypalaia:** Preserve butterfly-like shape; Querini castle is later and must not be shown in 1180.
- **Nisyros:** Emphasize volcanic caldera and older Paliokastro; Knights' castle belongs to a later era.

No files have been committed to GitHub; all are review candidates.
