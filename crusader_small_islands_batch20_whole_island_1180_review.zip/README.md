# Crusader Map — Batch 20, Whole-Island Painting Review (1180)

This is a **provisional alternate asset pack** for Sifnos, Kimolos, Ios and Amorgos, all previously represented in the GitHub island registry. It is **not yet committed or approved for final map placement**.

- All four paintings show full stylized islands, with the principal settlement enlarged relative to its geographic size. Painterly view is from the south looking north, but no strict orthographic or historical-geometry verification has been performed.
- Each individual image is an RGBA PNG. Its alpha was **reconstructed programmatically** from a source painting that used a pale RGB checkerboard, not native alpha. Check fine coastal rock halos and print edges.
- Preserve existing sprites as alternatives. These should replace an island's existing base decoration **and suppress duplicate settlement overlays** in the review render; do not accidentally paint the same village twice.
- The geographic bounding boxes are the repo's existing island bounds and are intended for initial registration only. The cutout coastline is illustrative; do not force exact waterline claims without a geographic mask and review.
- Sifnos's medieval fortified rings reflect later Western developments; the 1180 depiction is earlier and interpretive. Kimolos's surviving Chorio castle dates centuries later and is deliberately omitted. Amorgos's Hozoviotissa monastery traces its foundation traditionally to 1088, but the exact 1180 appearance is uncertain. Ios is an interpretive Byzantine hill village, not an architecturally reconstructed historic site.
- Ship sprites and ocean underlay belong to separate layers. Source sheet, checksum list and preview are included for QA.

Source notes:
- https://sifnos.gr/en/history/
- https://www.kimolos.gr/en/tourism-at-kimolos/going-to/10-identity-of-island/index.php?Itemid=77&id=40&option=com_content&view=article
- https://cyclades.culture.gov.gr/en/location/byzantine-amorgos/

**All assets: REVIEW / historical QA, coastline QA, alpha fringe QA and 300-DPI print QA still required.**
