# Crusader Map — Farming and Lowland Batch 22

Six new irregular transparent RGBA terrain sprites for the 1180 review map. These are **not yet uploaded to GitHub or geographically placed**. All are provisional and need visible-composition, alpha-edge, and 300-dpi print QA. The depicted Nile canals and meadow water must be masked/aligned to mapped hydrology.

Place beneath cities, roads, rivers and labels, above region-clipped green lowland underlay. Use only in the region pools listed by `manifest.json`; do not invent geographic coordinates or repeat the same tile in visible patterns.
