# Crusader Map — Batch 17 | Whole-Island Sprites (1180 review)

Four distinct **transparent RGBA** island sprites: Kefalonia, Milos, Thasos and Imbros. The entire island is included, and the main Byzantine settlement has been intentionally enlarged for map-scale legibility.

Camera convention: raised view from geographic **south looking north**; west is left/east is right. **No canvas map layers or baked-in ocean backgrounds** are part of the PNG sprites.

## Placement & QA

- **Provisional review ONLY.** No GitHub commit, approved sprite replacement, completed placement, or print approval.
- The sheet came with real alpha transparency. Crops preserve original alpha and remove faint, disconnected background pixels. See `alpha_preview_dark.jpg`.
- Geographic anchor is the existing `places.py` **ISLES** center, *not* a precise town coordinate. The full-island cutout must be geographically registered/warped against the map coastline before placement.
- Large settlements are intentionally out of scale, as requested. Do not simultaneously place separate city artwork on top of the same island and do not duplicate island underlays.
- Full-island shape and harbor relationships are illustrative; source geometry must be reviewed before promotion.
- Historical constraints: Kefalonia is Byzantine in 1180 (Norman takeover 1185); Milos volcanic bay and Byzantine settlement; Thasos Byzantine bishopric with ancient ruins; Imbros Byzantine Kastro/Kaleköy but later Italian defences excluded.

## Sources

- Kefalonia: https://visitkefaloniaisland.gr/wp-content/uploads/2022/01/%CE%91-STROLL-DOWN-HIST.-KEFALONIA.pdf
- Thasos municipality: https://thassos.gr/en/dimos/thasos-syntomi-istoriki-anaskopisi/
- Imbros architectural survey: https://ukaas.ktb.gov.tr/Eklenti/130273%2C14arastirma2pdf.pdf?0=
- Imbros history: https://islamansiklopedisi.org.tr/imroz

See `placement_manifest.json` for dimensions, island centers, SHA-256 hashes and QA flags.
