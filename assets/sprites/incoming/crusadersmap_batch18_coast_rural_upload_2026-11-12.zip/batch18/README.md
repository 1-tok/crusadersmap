# Crusader Map Batch 18 — coastal, infrastructure and rural stamps

28 individual RGBA sprite candidates, original RGB sheet and manifest. All generic and provisional. Alpha/background removal, crop boundaries, source resolution and historical applicability require manual QA. No map placement is approved. Do not use water sprites without georeferenced masking. Cross-bearing fortification/camp elements are not universally appropriate.
