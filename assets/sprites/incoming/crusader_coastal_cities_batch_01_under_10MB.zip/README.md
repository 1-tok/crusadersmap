# Crusader Map — Southern Levant coastal city sprites, batch 01

Five individual, transparent, label-free PNGs: **Ashkelon, Jaffa, Caesarea, Acre, Tyre**. Turquoise Mediterranean is on the **west (left)** in an elevated view from the south looking north. City names and map labels should be rendered **above** the sprites, not embedded into the paintings.

## GitHub upload
Upload the five files from `png/` to `data/sprites/coastal-corrections-2026-11-16/` in `1-tok/crusadersmap`. Upload `placement-manifest.json` separately to `data/manifests/coastal-city-corrections-batch-01-placement.json` if desired. Do not commit the ZIP to the sprite folder if the ingestion workflow cannot extract it. Existing Ashkelon registration in PR #74 refers to full-size source; this batch contains a size-optimized 1024px rendering, so use the **new SHA-256** in this manifest for these binaries.

## Anchors (longitude, latitude)

| City | Region | Lon | Lat | Notes |
|---|---|---:|---:|---|
| Ashkelon / Ascalon | main | 34.55 | 31.66 | Straight seawall west, curved landward defensive circuit |
| Jaffa | main | 34.75 | 32.05 | Compact port on rocky coastal rise |
| Caesarea | main | 34.89 | 32.50 | Small medieval enclosure amid Roman archaeology |
| Acre | main | 35.07 | 32.92 | Dense fortified port and harbour |
| Tyre | main | 35.20 | 33.27 | Peninsula/causeway-linked former island; **not** an elevated bridge |

## Placement safety

1. Use the coordinates already present in `places.py` / named sprite registry. The anchors are references, **not** arbitrary pixel offsets.
2. Place the city body on the landward side and fit painted water against the geographic coastline without spilling onto inland polygons. The overall Levant coast runs predominantly north/south, not NW/SE. Tyre is a geographic exception: sea wraps its exposed peninsula; its land bridge/causeway connects to the east.
3. Keep city, fortification and industrial sprites above terrain/field underlays, and city labels above sprites. Do not duplicate a site if existing artwork is retained.
4. Existing nine/30 painting holds should remain until a review composite demonstrates a valid site-specific replacement; preserve the source PNGs and previous versions.
5. Do not disturb the approved Dead Sea, Bayrut, Byzantium or Ayas.
6. At printed map scale, inspect western sea edges, east land edges, waterfront integration, orientation and label collisions before releasing active replacements.

**QA status:** PNGs packaged, automatically validated for transparency and checksums. Final historical specificity and coastline alignment still await map-scale review; this ZIP does not mark them as live in the renderer.
