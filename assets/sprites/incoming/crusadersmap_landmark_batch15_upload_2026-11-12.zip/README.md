# Crusader Map — Landmark Batch 15

Six individual RGBA sprites and the original 3-by-2 source painting. All are provisional, not production-approved, and no site coordinates are supplied. File names and CP site IDs are candidate associations. Run the GitHub sprite intake QA and verify south-facing oblique views, alpha seams, chronological phases and historical identity before activating map placement.
