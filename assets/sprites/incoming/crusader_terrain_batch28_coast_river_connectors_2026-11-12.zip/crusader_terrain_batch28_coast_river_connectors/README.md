# Crusader Map — Batch 28: coast and river connectors

12 individual RGBA sprites cropped from the source sheet (the first three rows), plus a manifest and original source sheet. The next three rows from the generated sheet are **excluded** because the priority is coastal, wetland and adjacent woodland transition artwork.

**Review only.** Placement is pending coastline/hydrology masking, inspection of transparency halos and native-resolution print QA. Never create fictitious watercourses or coastal arches to accommodate illustrative art. The coastal rock arch should remain gallery-only absent verified geography.

Rendering order: land/underlay, terrain connectors, geographically constrained hydrology/coastlines, sites/roads/labels.
