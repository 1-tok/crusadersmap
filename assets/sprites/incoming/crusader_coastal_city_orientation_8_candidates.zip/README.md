# Coastal city orientation candidates — review only

Eight individually cropped transparent PNG concepts from a generated sheet. These are NOT historically or geographically verified sprites. The named file prefixes reflect intended subjects, not confirmed accurate depictions. No placement authorization.
