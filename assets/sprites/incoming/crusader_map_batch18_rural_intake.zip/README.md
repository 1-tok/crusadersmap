# Crusader Map Batch 18 — six rural production sprites

Six RGB-to-RGBA cutouts from a new purpose-painted 3×2 sheet; original source sheet is provided separately. This package contains only six individual PNGs to avoid duplicate sheet ingestion.

All approved for **provisional map placement review** only. No precise coordinates or historic building identity are asserted. Crop boundary and transparency halos require visual checks before print use. Crop/source provenance retained in manifest.json.

Upload this ZIP to `assets/sprites/incoming/` on GitHub main. The existing Actions workflow should stage review assets and a pull request.
