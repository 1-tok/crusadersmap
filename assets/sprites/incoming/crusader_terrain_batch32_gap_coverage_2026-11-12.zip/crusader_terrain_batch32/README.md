# Batch 32: Crusader Map regional gap-coverage sheets

Three painted 1536 x 1024 PNG sheets and 32 transparent cutouts. All provisional, **not mapped or committed to GitHub**. 2026-11-12 audit does not prove exact uncovered regions of current full map. No sheets should be rendered directly in final map. Water/coast sprites require clipping to mapped hydrology; region pools require geographic review. Some native cutouts are < 800 px wide and need repaint for large print footprints.
