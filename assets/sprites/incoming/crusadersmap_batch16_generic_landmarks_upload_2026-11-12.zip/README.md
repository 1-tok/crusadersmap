# Crusader Map Batch 16 — six generic landmark cutouts

Not named historical sites. Six provisional RGBA assets and original RGB source sheet. Checkerboard background was digitally converted to alpha; inspect edges. The harbor, abbey, and maritime subjects cannot be historically assigned without further verification. No site IDs or map coordinates. Only use on generic asset review sheet until approved for a specific site.
