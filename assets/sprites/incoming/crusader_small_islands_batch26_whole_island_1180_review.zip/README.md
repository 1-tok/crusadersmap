# Crusader Map — Batch 26 Whole-Island Review Sprites (1180)

Includes Skiathos, Alonissos, Samothrace, Lefkada as **separate RGBA cutouts** with the main settlement intentionally enlarged. White RGB background has been converted to alpha; use `alpha_preview_dark.jpg` to inspect edges.

**Status: PROVISIONAL_ART_ONLY.** All four have prior repository island artwork. These are alternative candidates; never replace the existing source files or automatically place these until geographic silhouette and historical QA passes. The WGS84 bounds in the manifest refer to the geographic reference island, **not proof that the painterly silhouette is georeferenced**.

Perspective target is elevated view from geographical south looking north. Exact building plans, silhouettes and coastal orientation are unverified. The artwork deliberately excludes Skiathos Kastro (~1360), later Venetian Ghisi embellishments on Alonissos, late Gattilusio towers on Samothrace, and Santa Maura Castle (~1300) at Lefkada.

When placing whole-island sprites, suppress duplicated older island decoration and standalone town icons within the same footprint only after approving the replacement.

Source references include UN-Habitat Skiathos Kastro report, Management Unit of Alonissos Northern Sporades National Park, Archaeological Museum of Samothrace, and Municipality of Lefkada historical notes.

QA correction: extracted each island by connected painted components rather than quadrant rectangles; detached shore rocks preserved, cross-island stray fragments removed.
