# Coastal Cities — Batch 01 (provisional)

Four independent RGBA PNG sprites extracted from the 2×2 painted sheet. Ordered top left Gaza, top right Ascalon, bottom left Jaffa, bottom right Caesarea. Their exact historical architecture, waterfront orientation and shoreline placement have **not** been independently verified. Treat as candidates for map review, not approved replacements.
