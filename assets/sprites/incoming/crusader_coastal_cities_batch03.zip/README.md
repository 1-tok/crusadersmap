# Crusader Map Coastal City Batch 03

Byblos, Batroun, Tripoli and Tartus, four provisional south-facing coastal city paintings.

Each city was cut from the 2x2 generated sheet and checkerboard near-white pixels were automatically removed to reconstruct alpha. The source was RGB, **not native transparent**, so check fringe pixels and detail holes before approval. Intended Mediterranean sea to image left/west; geographic coastline, 1180-period architecture and historical harbor layouts **not yet verified**. Keep existing approved artwork until candidates pass QA.
