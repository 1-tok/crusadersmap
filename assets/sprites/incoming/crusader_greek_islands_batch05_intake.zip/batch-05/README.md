# Crusader Map — Greek Islands Batch 05 — Intake ZIP

Four original generated RGBA PNG artworks with transparency. User approved them for *provisional visual review*.

**IMPORTANT:** The images resemble subjects from Batch 04. They are intentionally unassigned, not verified geographic portrayals of Agathonisi, Pserimos, Telendos or Meganisi. Do not place these on actual map coastlines yet. They require redraw/geo-registration and red-edge cleanup.

Upload ZIP to GitHub intake, targeting `data/sprites/greek-islands/batch-05/` on branch `artwork/greek-islands-batch-05-review` (or equivalent intake branch) without overwriting old artwork. Review approval does not equal historical or print approval. The manifest intentionally keeps `placement.enabled=false`.
