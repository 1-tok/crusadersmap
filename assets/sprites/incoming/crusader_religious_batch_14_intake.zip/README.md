# Crusader Map religious landmark batch 14

12 provisional sprites extracted from an RGB sheet. Their original pale backing was approximated with alpha-matting, not a lossless extraction. Do not declare them print approved.

Subject names describe the artwork; candidate sites are **not verified identities**. In particular the Hagia Sophia concept contains post-1453 minaret imagery and must not represent 1180. Most sprites are unlocated and should be registered for review, not automatically placed.

Upload individual PNGs and same-stem JSON metadata via the existing GitHub intake, or upload this ZIP if the ZIP intake workflow is active. Original source included under originals/.
