# Crusader Map — Batch 29, Whole-Island Review (1180)

Four separate transparent PNG sprite candidates: Kalymnos, Symi, Tilos and Delos. They use an elevated view from geographical south, looking north, with settlements enlarged for map legibility.

## Placement status
**PROVISIONAL ART ONLY. NOT GEOREGISTERED. NOT APPROVED FOR FINAL MAP.** Existing island artwork and historical QA states are preserved; no GitHub changes have been made.

The PNG alpha channel was reconstructed from an RGB/off-white generated image. Edges were checked on dark backing but require final print-production review. Geo bounds in the manifest are existing repository island bounds for Kalymnos, Symi, Tilos; Delos has only a provisional center.

Delos must remain an archaeological ruin island, **not** a contemporary Byzantine city: Greek cultural authorities describe the settlement as abandoned by the 8th century. Kalymnos depicts a modest early Byzantine nucleus without later Knights-period enlargement.

## Contents
* Four separately named RGBA PNG sprite files
* `placement_manifest.json` with historic/map details and review flags
* `alpha_preview_dark.jpg` for transparent-edge QA
* `source_sheet_rgb.png` original untouched image
* `SHA256SUMS.txt` integrity verification

## Review gates
Historical chronology, geographic shape vs authoritative coastlines, map-footprint registration, actual south-north viewpoint, pale edge halos, and print-resolution checks. Never substitute a stylized sprite's silhouette for authoritative GIS land/water masks without explicit review.
