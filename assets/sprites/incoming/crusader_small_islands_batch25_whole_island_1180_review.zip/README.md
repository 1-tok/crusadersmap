# Crusader Map — Batch 25 Whole-Island Sprites (1180 review)

Contents: Spetses, Agistri, Paxos and Antipaxos. Four independent RGBA cutouts cropped from the original sheet, preserving native transparency and minor coast/islet details. Source and preview included.

**Status: PROVISIONAL_ART_ONLY.** These are enlarged illustrative whole-island artworks for visual review, **not coastline-registered** or automatically approved for map replacement. Existing project candidates remain untouched. No GitHub commit performed.

- Camera: elevated south-looking-north. No mirroring.
- No later Venetian defenses or large anachronistic ports are intended.
- Agistri's documented medieval settlement history is uncertain and often described as abandonment; its one building is conjectural.
- Spetses has sparse 1180 settlement evidence; no large Byzantine harbor town is implied.
- Paxos: steep western cliffs, greener eastern coast; medieval hamlet and church drawn interpretively.
- Antipaxos: modest rural footprint, no major city.
- All shoreline silhouettes are painterly simplifications and may distort physical outlines.
- Before rendering, compare each image to the base geographic coastline, review sea-side and historical accuracy, avoid duplicate island and city painting, and check print-resolution alpha edges.

The placement manifest has auto_place=false and enabled=false.
