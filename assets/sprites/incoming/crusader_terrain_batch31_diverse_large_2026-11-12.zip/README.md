# Batch 31 — Large varied terrain sprites

Four standalone large RGBA terrain cutouts. Terrain matches regional pools only; fit to actual map gaps and terrain masks before placing. All are provisional review-only and require alpha edge, ecology and print-scale QA.
