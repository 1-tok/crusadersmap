# Batch 34 — peripheral terrain

Eight separate original-size RGBA paintings. Region pools are not coordinates. All assets eligible for review **only after geographic clipping** and alpha-fringe QA. The coastal artwork must be masked to real coastline. Do not render outside actual map borders. No sprite here is print-approved.
