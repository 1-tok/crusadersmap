## Crusader Map — lowland and Nile Delta follow-on sprites (Batch 10–11)

27 separate RGBA irregular-edge PNGs, plus two preserved original master sheets.

Batch 10: Nile Delta fields, floodplain channels, reeds, palms, marsh. Batch 11: Greek/Cypriot/Anatolian/Levantine lowland plains, olive groves, fields and coastal edges.

**IMPORTANT:** No geographic placement yet. All hydrology and coastal features must be masked/rotated to match map coastlines, bank directions and medieval geography. Southern-looking-north viewpoint and period suitability require visual review. The extraction preserves each component in its own PNG without claiming QA or print certification.

Upload ZIP through GitHub incoming intake if desired. Do not place masters as sprites.
