# Crusader Map Batch 30 — large regional transitions

Two full-size transparent RGBA map terrain sprites, not small-sheet crops. Review-only placement eligibility. Check colored alpha halos, print pixel density and river alignment before map compositor use. Not yet in GitHub.
