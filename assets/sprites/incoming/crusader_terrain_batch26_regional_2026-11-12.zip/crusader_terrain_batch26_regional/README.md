# Crusader Map — regional terrain batch 26

Eight RGBA PNG sprites: two previous mountain scenes and six new region cutouts. Batch 24 rejected artwork excluded.

Use on review map only after matching correct inset/frame, clipping waterways, checking labels and named-site artwork, and checking transparency halos. Never treat this import as proof of geographic placement or 300-dpi approval.

See manifest.json for individual image size, SHA256 and suggested regions.
