# Crusader Map Batch 17 — trade and production

Four nonduplicate infrastructure candidates: medieval shipyard, salt pans, desert caravan well, pottery/brick kilns.

**Provisional artwork only.** The source RGB painting has a pale checkerboard baked into the background; reconstructed alpha may retain halos and must be visually inspected. Coordinates and site identities are not invented. All four are approved for map-placement *review*, not automatically located.

Source art is preserved unchanged in the `originals/` directory inside this archive.
