# Crusader Map — Batch 19 mixed generic sprites

31 transparent RGBA sprite crops plus original sheet and manifest. Provisional imagery only; no fixed locations or map approval. Original image RGB checker-white required reconstructed alpha; check seams/fringes, duplicated content and all historical flags. Upload ZIP to assets/sprites/incoming on main, review automated intake PR.
