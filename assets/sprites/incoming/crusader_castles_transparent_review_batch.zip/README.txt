Crusader Map — four individual transparent RGBA PNG review candidates.
Château Pèlerin / Atlit, Montfort, Margat, Safed.
Art is provisional, not historically certified or map-placement approved.
