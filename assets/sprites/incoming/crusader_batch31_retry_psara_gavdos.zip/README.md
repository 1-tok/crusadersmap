# Crusader Map — Batch 31: remaining Greek island review candidates (c.1180)

Four individual transparent RGBA PNGs: Psara, Gavdos, Elafonisos, Antikythera.

**Approval: PROVISIONAL_ART_ONLY / do not auto-place.** No repository files overwritten or commits performed.

Audit result: The project repository already has candidate Greek island artwork for 71 subjects. Psara, Gavdos and Elafonisos have earlier unapproved Batch 03 placeholder candidates; these drawings are optional upgrades, not unique locations. Antikythera is a proposed new site, not yet registered.

Viewpoint: elevated camera due south looking north, intended but not formally verified against geography. Buildings intentionally exaggerated for map readability, except Elafonisos largely deserted; coastlines are painterly approximations and must NOT be substituted for true geographic masks without manual reconciliation.

Source had a near-white background (not native transparency); cleaned by component-aware white matte extraction and examined on a dark background. Fine edge cleanup is still required before print.

References: Elafonisos island history (https://elafonisos.inspacetime.gr/en/elafonisos/history); UCL archaeological research on Antikythera (https://discovery.ucl.ac.uk/id/eprint/174663/1/174663_Palmeretal10_postprint.pdf). Check other specific architectural/landform details with ground truth before placement.

Archive includes original RGB sheet, per-island PNGs, manifest, QA preview, SHA-256 checksums.
