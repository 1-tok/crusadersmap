# Crusader Map — Batch 27 (1180)

Subjects: **Ithaca, Euboea, Karpathos, Kasos**. Four independent full-island cutouts, with intentionally exaggerated settlements for the final map.

- Intended perspective: elevated view looking geographically north from the south.
- New artwork is **provisional review only**, not geographically approved and not yet committed to GitHub.
- Original RGB source has visible checkerboard. Transparency was reconstructed and requires edge cleanup for print quality.
- The WGS84 bounding boxes in the manifest are copied from the existing island registry; they are **not** proof that the new painted coastline is aligned with the real shore.
- Preserve existing island artwork until new replacements pass historical/geometry QA.
- No automated map placement or override of existing selected artwork.

The `source_sheet_rgb_checkerboard.png` is preserved for repainting; `alpha_preview_dark.jpg` is included for transparency QA.
