# Greek Islands — Batch 08

Six new island *concepts*, numbered 86–91. Original artwork includes historically speculative castles, towns and churches, especially inappropriate for sparsely inhabited islands; treat as placeholders for repaint. Coastline shapes are not geo-registered and final-map placement is disabled. Background converted from white to transparent; alpha edges require visual cleanup. Preserve artwork for comparison, not for final geographic overlays.
