# Location-aware terrain underlays (1180)

Derived from the composite gap-cell register, not arbitrary sprite positions.

Use: `python3 build_location_underlays.py --csv reports/composite-2026-11-12/terrain-gap-cells.csv --out assets/terrain/underlays/gap_20261112`

**Critical:** The underlay SVGs are transparent, use 10800×14400 print-sheet coordinates, and must be clipped to geographic land geometry before integrating after the land base but before all existing terrain stamps. They are not final map renderings. Never cover seas, rivers, inset frames or labels.

The fallback package contains 32 measured flat cells from the report. Rerunning against the complete CSV adds all 133 flat/thin cells, including Aegean patches. Opacity and footprint are deliberately restrained to keep existing sprites dominant.

After integration, rerun the terrain-gap report and inspect geographic crop comparisons to determine whether any region still needs additional underlay paint.
