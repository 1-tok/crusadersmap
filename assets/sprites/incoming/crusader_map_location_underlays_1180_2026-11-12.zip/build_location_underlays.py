#!/usr/bin/env python3
"""Create location-targeted transparent SVG terrain underlays from measured composite gap cells.
Run at Crusader Map repository root with:
  python tools/build_location_underlays.py --csv reports/composite-2026-11-12/terrain-gap-cells.csv --out assets/terrain/underlays/gap_20261112
Underlays must be inserted after land base and before terrain sprites, and clipped to actual land masks.
"""
import csv, argparse, pathlib, random, math, json, hashlib, collections, html
from xml.sax.saxutils import escape
FLAT_DATA = '''main|Cilicia and the Taurus|7360|320|320|9.2
main|North Syria (Antioch, Aleppo)|9280|4480|320|8.7
main|North Syria (Antioch, Aleppo)|10240|4800|320|8.0
main|Syrian desert|10240|6080|320|7.6
main|Syrian desert|10240|6720|320|11.6
main|Syrian desert|10240|7680|320|9.2
main|Syrian desert|9920|8320|320|8.8
main|Lebanon and Damascus|9280|7680|320|11.2
main|Lebanon and Damascus|9280|8640|320|9.7
main|Transjordan and Hauran|9600|8960|320|11.2
main|Transjordan and Hauran|9600|9280|320|9.9
main|Transjordan and Hauran|9920|9600|320|9.2
delta|Egypt inset: Sinai|2790|10721|200|11.1
delta|Egypt inset: Sinai|3790|12721|200|11.8
delta|Egypt inset: Sinai|4190|12921|200|10.1
delta|Egypt inset: Sinai|2590|13121|200|10.2
delta|Egypt inset: Sinai|2790|13521|200|9.0
delta|Egypt inset: Delta|1390|10721|200|11.9
delta|Egypt inset: Western and Eastern deserts|2190|11121|200|9.4
delta|Egypt inset: Western and Eastern deserts|2390|12321|200|7.8
delta|Egypt inset: Western and Eastern deserts|1790|12721|200|11.9
delta|Egypt inset: Western and Eastern deserts|2190|12721|200|11.6
delta|Egypt inset: Western and Eastern deserts|990|13121|200|10.4
delta|Egypt inset: Western and Eastern deserts|1390|13121|200|11.1
delta|Egypt inset: Western and Eastern deserts|1590|13121|200|11.7
delta|Egypt inset: Western and Eastern deserts|2390|13121|200|11.7
delta|Egypt inset: Western and Eastern deserts|390|13321|200|11.7
delta|Egypt inset: Western and Eastern deserts|1590|13321|200|10.7
delta|Egypt inset: Western and Eastern deserts|390|13521|200|9.6
delta|Egypt inset: Western and Eastern deserts|1390|13521|200|11.8
delta|Egypt inset: Western and Eastern deserts|1590|13521|200|3.4
delta|Egypt inset: Western and Eastern deserts|2190|13521|200|9.4'''
FALLBACK = [dict(region=p[0],zone=p[1],sheet_x=int(p[2]),sheet_y=int(p[3]),cell_px=int(p[4]),detail=float(p[5]),flat=True) for p in (line.split('|') for line in FLAT_DATA.splitlines())]
GROUPS = {
 'egypt_desert': ['Egypt inset: Western and Eastern deserts'],
 'sinai_negev': ['Egypt inset: Sinai','Negev, Sinai, Arabah'],
 'syrian_steppe': ['Syrian desert','Transjordan and Hauran'],
 'levant_mountain': ['Lebanon and Damascus','Cilicia and the Taurus'],
 'northern_syria': ['North Syria (Antioch, Aleppo)'],
 'nile_delta': ['Egypt inset: Delta'],
 'aegean': ['Aegean inset: Anatolia and Thrace','Aegean inset: Greece and the Balkans']
}
STYLES = {
 'egypt_desert':dict(base='#D7AF75',a='#9B855F',b='#EACD98',kind='sand'),
 'sinai_negev':dict(base='#CFA16D',a='#8E826B',b='#E0B987',kind='rock'),
 'syrian_steppe':dict(base='#BCAA77',a='#717D53',b='#DBBD86',kind='steppe'),
 'levant_mountain':dict(base='#A7A480',a='#627251',b='#BDB18D',kind='rock'),
 'northern_syria':dict(base='#B4A775',a='#6E7B4B',b='#D1BD8B',kind='steppe'),
 'nile_delta':dict(base='#879B69',a='#668359',b='#C9B579',kind='field'),
 'aegean':dict(base='#A4AA7B',a='#5F754D',b='#C7B98A',kind='field')
}
def load_rows(path):
 if path and pathlib.Path(path).exists():
  with open(path,newline='',encoding='utf-8-sig') as f:
   return [dict(region=r['region'],zone=r['zone'],sheet_x=int(r['sheet_x']),sheet_y=int(r['sheet_y']),cell_px=int(r['cell_px']),detail=float(r['detail']),flat=float(r['detail'])<12) for r in csv.DictReader(f)]
 return FALLBACK

def cell_svg(r,group):
 x,y,s=r['sheet_x'],r['sheet_y'],r['cell_px'];style=STYLES[group]; rng=random.Random(int(hashlib.sha256(f'{group}|{x}|{y}'.encode()).hexdigest()[:12],16))
 # Audit sheet_x/y are sample-cell coordinate references, treated here as centers;
 # use conservative 80%-cell footprint to avoid expanding into adjacent unstated land.
 extent=s*.40; cx=x;cy=y; rad=s*.58
 out=[f'<g class="measured-land-cell" data-zone="{escape(r["zone"])}" data-detail="{r["detail"]}" data-x="{x}" data-y="{y}">',f'<ellipse cx="{cx}" cy="{cy}" rx="{extent:.1f}" ry="{extent:.1f}" fill="{style["base"]}" opacity="0.25" filter="url(#soft)"/>']
 # Micro texture is procedural and not geographically asserted roads/streams/structures.
 for k in range(54 if s==320 else 30):
  px=cx+rng.uniform(-extent*.9,extent*.9);py=cy+rng.uniform(-extent*.9,extent*.9)
  dx=(px-cx)/extent;dy=(py-cy)/extent
  if dx*dx+dy*dy>0.85:continue
  color=style['a'] if rng.random()<.65 else style['b']
  opacity=round(rng.uniform(.10,.29)*(1-min(1,dx*dx+dy*dy)),2)
  if style['kind']=='sand':
   length=rng.uniform(4,18)*s/320
   out.append(f'<path d="M{px:.1f} {py:.1f} q {length:.1f} {-2*s/320:.1f} {length*1.7:.1f} 0" fill="none" stroke="{color}" stroke-width="{rng.uniform(.8,2.4):.1f}" opacity="{opacity}"/>')
  elif style['kind']=='rock':
   rpx=rng.uniform(1.7,7)*s/320
   out.append(f'<path d="M{px-rpx:.1f} {py+rpx/2:.1f} l{rpx:.1f} {-rpx:.1f} l{rpx:.1f} {rpx:.1f}Z" fill="{color}" opacity="{opacity}"/>')
  elif style['kind']=='field':
   L=rng.uniform(5,19)*s/320
   out.append(f'<path d="M{px:.1f} {py:.1f} l{L:.1f} {-L*.16:.1f}" stroke="{color}" stroke-width="{rng.uniform(1.2,2.8):.1f}" opacity="{opacity}"/>')
  else:
   out.append(f'<path d="M{px:.1f} {py:.1f} l{-2*s/320:.1f} {-5*s/320:.1f} m{2*s/320:.1f} {5*s/320:.1f} l{2*s/320:.1f} {-4*s/320:.1f}" stroke="{color}" stroke-width="1.4" fill="none" opacity="{opacity}"/>')
 out.append('</g>');return '\n'.join(out)

def render(rows,group):
 content='\n'.join(cell_svg(r,group) for r in rows)
 return f'''<svg xmlns="http://www.w3.org/2000/svg" width="10800" height="14400" viewBox="0 0 10800 14400">
<title>1180 Crusader Map - {group} location-specific terrain underlay</title>
<desc>Conservative transparent gap texture beneath existing sprites; MUST clip against geographic land masks before print; not a coastline or hydrology replacement.</desc>
<defs><filter id="soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14"/></filter></defs>
<g id="underlay-{group}" opacity="0.83">{content}</g></svg>'''

def main():
 p=argparse.ArgumentParser();p.add_argument('--csv',default='reports/composite-2026-11-12/terrain-gap-cells.csv');p.add_argument('--out',default='assets/terrain/underlays/gap_20261112');a=p.parse_args();rows=load_rows(a.csv); out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
 assets=[]
 for group,zones in GROUPS.items():
  selected=[r for r in rows if r['zone'] in zones]
  if not selected:continue
  name=f'underlay_{group}.svg';svg=render(selected,group);(out/name).write_text(svg,encoding='utf-8');assets.append(dict(id='gap-'+group,source=name,zone_labels=zones,cell_count=len(selected),priority='P0' if group in ('egypt_desert','sinai_negev','syrian_steppe') else 'P1',style=STYLES[group]['kind'],render_status='generated_unintegrated',clip_to='actual landcover vector mask (required)',z_order='geographic base < new underlay < existing terrain stamps < waterways, roads, sites and labels'))
 manifest=dict(schema_version=1,batch='1180-geographic-terrain-gap-underlays',source_csv=a.csv if pathlib.Path(a.csv).exists() else 'fallback measured flat cells from terrain-gap-report.md (32 cells)',generated_cells=len(rows),full_sheet_dimensions=[10800,14400],coordinate_system='print-sheet pixels, main and both insets already positioned on same sheet',purpose='underpaint thin and flat measured land cells between sprites',estimated_gap_cells_only=True,requires_geographic_land_mask=True,requires_compositor_integration=True,approved_for_provisional_visual_review=True,print_approved=False,assets=assets,important='Aesthetically subdued semi-transparent paint. Does not create new water or topographic features. Integrate only after clip-to-land and rerun measured gap report; do not confuse generation with confirmed placement.')
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'README.md').write_text('# Location-aware terrain underlays (1180)\n\nDerived from the composite gap-cell register, not arbitrary sprite positions.\n\nUse: `python3 build_location_underlays.py --csv reports/composite-2026-11-12/terrain-gap-cells.csv --out assets/terrain/underlays/gap_20261112`\n\n**Critical:** The underlay SVGs are transparent, use 10800×14400 print-sheet coordinates, and must be clipped to geographic land geometry before integrating after the land base but before all existing terrain stamps. They are not final map renderings. Never cover seas, rivers, inset frames or labels.\n\nThe fallback package contains 32 measured flat cells from the report. Rerunning against the complete CSV adds all 133 flat/thin cells, including Aegean patches. Opacity and footprint are deliberately restrained to keep existing sprites dominant.\n\nAfter integration, rerun the terrain-gap report and inspect geographic crop comparisons to determine whether any region still needs additional underlay paint.\n')
 print(json.dumps({'output':str(out),'cells':len(rows),'layers':[(a['id'],a['cell_count']) for a in assets]}))
if __name__=='__main__':main()
