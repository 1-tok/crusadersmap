# Crusader Map fortress Batch 19
Four independent southern elevated oblique concept paintings, review placement only.
No inferred coordinates. No production/print certification.
Original image generator sheet has pale checkerboard embedded; extracted alpha is an estimated matte requiring edge QA.

- Qal’at Najm: 627 × 613 px; provisional placement review; South elevated oblique; 1180 variant must omit major Ayyubid works of 1208–1215. River crossing at historic Euphrates level.
- Qal’at Ja’bar: 627 × 530 px; provisional placement review; Zengid-era river promontory, NOT island in modern Lake Assad. Minaret architecture must be checked.
- Birecik castle: 627 × 544 px; provisional placement review; Do not depict 15th-century Mamluk town gates or later wall fabric in 1180.
- Harran citadel: 627 × 397 px; provisional placement review; Pre-Ayyubid phase for 1180; verify exact wall profile.
