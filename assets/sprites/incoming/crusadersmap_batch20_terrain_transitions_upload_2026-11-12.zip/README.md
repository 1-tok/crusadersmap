# Crusader Map Batch 20 — 9 large terrain-transition sprites

Nine individual RGBA cutouts, source sheet, and manifest. Original alpha preserved. Approved only for intake/visual review, not final map or 300 DPI print. Do not place illustrated rivers/coasts away from geographic source features. Buildings must be checked or masked.
