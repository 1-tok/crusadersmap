# Crusader Map terrain Batch 27 — other gaps

22 individual terrain cutouts separated from two source sheets. Provisional review only; automated white-background removal needs inspection, and all hydrology and coastline elements require precise geographic masks. No sprites are committed to GitHub or placed on the final map.
