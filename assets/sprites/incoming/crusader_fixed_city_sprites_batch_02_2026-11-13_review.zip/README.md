# Crusader Map — Named city orientation fix, Batch 02

Contains **two** new, individual transparent RGBA candidates: Chalcedon and Alexandria, both intended for 1180. Their original site-specific PNGs on GitHub remain the selected map assets until manual review approves these replacements. **No generic fallback sprites are included.**

- **Chalcedon:** viewed from south, low Byzantine peninsula with Marmara at the front and historical harbors on northwest/east flanks. Building massing remains interpretive; keep regional Constantinople-detail view constraints.
- **Alexandria:** viewed from south, Mediterranean north/rear and Pharos/harbor relationship. This image was safely isolated from one earlier **three-scene** generator output (via alpha connected components) with no adjacent cutout; the result is a standalone PNG. Lighthouse and city silhouette remain speculative. Source art comes close to the left edge; inspect alpha/crop carefully before print.
- **Damietta:** not delivered in this batch. Its generated candidate erroneously used Crusader heraldry, so it was rejected. An accurate 1180 city sprite must locate the old settlement on the east bank of the Nile, before its 1250 destruction/relocation.

Both PNGs are **provisional only**. No branch/PR/commit has been made and no current production sprite overwritten. See manifest.json for SHA256, historical caution, orientation and approval state. No claim of exact archaeological reconstruction is made.
