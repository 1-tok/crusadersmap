# Crusader Coastal Cities — Batch 02

Acre, Tyre, Sidon, Beirut. Four individual RGBA sprites, south-view proposals.

**Review only.** Orientation, skyline/period details, true shoreline topology and alpha edges have not passed map placement QA. Tyre especially requires detailed peninsula/causeway verification. Do not overwrite existing primary sprites without comparison.
