# Named-site coastal orientation correction batch — 13 November 2026

**Production approval: NO.** This package does not replace any existing repository PNG.

Contains **one** new standalone, transparent, named-city repaint candidate: Byzantine Constantinople circa 1180. Three additional named cities are recorded in `manifest.json` as *requiring repaint*, because generated city sheets did not pass the required individual site/geography QA. No generic sheet crops have been substituted.

## Constantinople
- Visual style: original Crusader Map fine ink-and-watercolour city art (interpretive recreation).
- View: elevated from geographical south, looking north.
- Sea of Marmara at the front/south, Golden Horn at rear/north, Bosphorus on the right/east.
- Western Theodosian walls, Hagia Sophia without Ottoman minarets, Hippodrome in eastern half.
- Transparent RGBA PNG. Trimmed low-alpha fringes and padded empty transparent border.
- **Do not place on regional Aegean view:** existing repo places Constantinople in a special detail context at double size; use same site anchor/scale constraints.

## Awaiting genuine site-specific repaint
- **Chalcedon:** Marmara front; Bosphorus west/left; low Asian-shore city.
- **Alexandria:** Mediterranean north/rear; two ancient harbors and Pharos; no later Qaitbay fortress.
- **Damietta:** pre-1250 east-bank river-mouth town; do not confuse with relocated later Damietta.

All four sites already have dedicated sprite images in the repo. Existing assets remain the default; do not use generic cutouts in their place. No new binaries have been committed to GitHub in this batch.
