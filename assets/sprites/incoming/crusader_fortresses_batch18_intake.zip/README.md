# Crusader Map Fortress Batch 18

Four provisional candidate sprites: Sis/Kozan, Toprakkale/Til, Korykos mainland fortress (not Kızkalesi), Softa Kalesi. Southern elevated oblique view, transparent RGBA, independent placeable sprites. Images are interpretive visual concepts, not architecturally certified reconstructions.

Approval: approved for visual map-placement review only. GIS coordinates remain unset pending site reconciliation; do not auto-place, do not approve for final print or infer circa-1180 fabric from later remains. Apply coastline review for Korykos and Softa.
