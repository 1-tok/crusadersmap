# Crusader Map — Greek Islands Batch 09

Six distinct **concept targets**: Thirasia, Despotiko, Dia, Antimilos, Imeri Gramvousa, and Chrysi. The generated sheet was RGB with a baked-in pale checkerboard; background removal was automated and requires visual alpha QA. Historic circa-1180 architecture and settlement scale are not verified; the castles and monumental buildings are especially unsuitable as literal depictions for many islands. These are unplaced concept assets, not geographically accurate coastlines. Their intended names should not be used for map placement until geography-specific redraws are completed.

The full original sheet is included for reference. Placement is disabled in the manifest.
