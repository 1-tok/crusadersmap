# Terrain Batch 29 — large coverage sprites

Six wide RGBA PNGs for provisional geographic map review. No coordinates assigned. All six need alpha halo, fit and print-scale QA; water-bearing sprite must match mapped hydrology. Not uploaded to GitHub.
