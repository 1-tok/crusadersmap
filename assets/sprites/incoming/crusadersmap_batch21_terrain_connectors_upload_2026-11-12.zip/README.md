# Batch 21 — Terrain Connector Cutouts

21 generic transparent PNG connector candidates, original RGB source sheet and machine-readable manifest. These are provisional: automatic white/checkerboard background removal may leave halos or translucent light terrain. Inspect on light and dark backgrounds before approval. Source grid is 1536×1024, so native resolution is low for giant 300 DPI placements. No site-specific historic identity or surveyed georeference. Water pieces must be masked to genuine coastline/river outlines; follow the south-facing oblique atlas viewpoint. This pack contains no opaque gap-fill rectangles and does not replace the four original underlay designs.

Intended GitHub upload destination: assets/sprites/incoming/ on main. Intake auto-QA and review PR should be checked before merging.
