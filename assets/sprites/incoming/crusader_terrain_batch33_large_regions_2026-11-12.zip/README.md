# Batch 33 — Large regional terrain sprites

Four individual 1774 × 887 px transparent PNG assets. Provisional 1180 map review candidates only; position after comparing with actual map rendering. No measured coverage claim. Red/yellow alpha fringes require cleanup before final placement. See manifest.json for regional restrictions and checksums.
