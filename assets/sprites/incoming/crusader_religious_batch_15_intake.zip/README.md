# Crusader Map Religious Landmarks — Batch 15

12 original-size transparent RGBA cutouts for **provisional map-placement review**. Image identity is generic; candidate names are research suggestions only. Historical architecture, dates, orientation and exact geographic placement are not verified. Some sprites touch sheet-cell edges; inspect these before print. Preserve the original source.

Upload this ZIP into `assets/sprites/incoming` on main to trigger the GitHub intake Action and subsequent review PR. The original source painting is preserved separately; do not ingest the full collage as an individual sprite.
