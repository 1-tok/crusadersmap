# Crusader Map — Greek Islands Batch 10

Targets: Agios Efstratios, Peristera, Kyra Panagia, Gioura, Piperi and Skantzoura.

The six PNGs are illustrative **concepts**, not historical or geographically registered island overlays. The generator added inappropriate castles, windmills, large churches and classical architecture. Several islands should have little or no built development in the circa-1180 depiction. The source used a printed checkerboard; background extraction is approximate and requires manual alpha cleanup.

**Placement:** disabled in `placement_manifest.json`; do not place on the production map. Repaint using geographic coastlines, natural cover and sparse structures, then re-review.
