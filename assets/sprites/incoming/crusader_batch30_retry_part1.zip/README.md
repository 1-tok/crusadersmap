# Crusader Map — Batch 30 whole-island candidates (1180)

**Status: PROVISIONAL ART, NOT APPROVED FOR MAP PLACEMENT.**

Contains four individual RGBA sprites cut from `source_sheet_rgb_checkerboard.png`, with reconstructed exterior transparency and source preserved for future remasking. The perspective is intended as elevated from geographical south; orientation is NOT geospatially verified. The atlas deliberately enlarges small communities, while the island coastlines remain interpretive and must not be used as geographically precise replacements without QA.

- Rhenia/Rheneia: ancient ruins, necropolis and farmsteads, narrow isthmus, no flourishing medieval town.
- Antiparos: do not use its Venetian castle (ca. 1440) in an 1180 depiction.
- Agathonisi: very limited claim about medieval occupation; tiny settlements are artistic, not archaeologically verified.
- Telendos: separated from Kalymnos in late antiquity, early Christian and early Byzantine ruins.

No repository changes were made, and existing sprites/QA states should be retained. Placement manifest includes approximate named-site anchors (Rhenia and Antiparos from the old provisional manifest; Agathonisi and Telendos approximate), NOT verified island bounding boxes. Do not auto-register or georeference these PNGs.

Research references:
- https://archaeopresspublishing.com/ojs/index.php/JGA/article/view/3347
- https://www.visitgreece.gr/en/experiences/culture/archaeological-sites-monuments/castle-of-antiparos
- https://kalymnos.gr/en/activities/places-to-visit-sightseeings/archaeology/
- https://golden-greece.gr/en/islands/dodekanisa/agathonisi/history

Dark-background preview: `alpha_preview_dark.jpg`. SHA-256 checksums in `SHA256SUMS.txt`.
