# Crusader Map — Greek Islands Batch 04 (draft)

Four transparent RGBA concept sprites for Arki/Marathi, Oinousses, Fournoi, Antikythera. These are **not coastline registered** and are **not approved for map placement**. Review speculative medieval buildings and red fringe artifacts before map placement.

Target upload directory: `data/sprites/greek-islands/batch-04/`.
