# Crusader Map — Civic infrastructure Batch 16

7 distinct map-sprite concepts extracted from the second concept sheet.
Approve only for **provisional artwork and map-placement review**.
These are generic illustrations, not verified buildings or georeferenced structures.

The source was RGB with a light patterned background. The PNGs are now RGBA
with reconstructed alpha, but residual halos, edge clipping and semitransparent
stonework require human QA before final print.

All identities are descriptive, not historical. Coordinates and dates are
not verified. The existing GitHub sprite-intake workflow should register the
PNG files and sidecar metadata after this ZIP is uploaded to:
assets/sprites/incoming/

Do not ingest the source collage as an individual sprite. Preserve the
original source sheet separately for possible better future extraction.

Extracted, in order:
1. Windmill and farm
2. Fortified river bridge
3. Hillside aqueduct
4. Domed bath complex
5. Fortified caravanserai
6. Coastal watchtower
7. Terraced vineyard estate
