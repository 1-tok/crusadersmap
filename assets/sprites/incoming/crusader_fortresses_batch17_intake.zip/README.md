# Fortress Batch 17 — Crusader Map
Four separate RGBA PNGs plus matching JSON sidecars.
Review-map placement approved in editorial sense only; geographic coordinates and construction phases unverified. Do not automatically place or promote to production.
Drawing order: top left Ravanda, top right Savranda, bottom left Tumlu, bottom right Gökvelioğlu.
Southern elevated oblique viewpoint. No invented faction banners.
