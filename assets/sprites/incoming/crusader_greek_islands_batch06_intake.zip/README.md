# Greek Islands Batch 06

Four transparent draft concepts: Othonoi, Ereikoussa, Mathraki and Saria.

These are **not** exact geographic representations; the subject names denote intended repaint/placement targets. Buildings are illustrative, not verified circa-1180 reconstructions. Color fringe and coastline QA remain outstanding.

Map placement is disabled until island shapes are verified and accurately georeferenced. Place only in a concept-review gallery, not on the final map.
