Six separate transparent RGBA PNG concepts. These are unapproved draft candidates, NOT geographically or historically validated named-city sprites. See manifest.json.
