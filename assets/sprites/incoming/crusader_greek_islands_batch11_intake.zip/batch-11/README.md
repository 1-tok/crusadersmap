# Greek Islands — Batch 11, Ionian minor-island concepts

Targets: Kalamos, Kastos, Atokos, Arkoudi, Oxia, Petalas. Six selected PNG concepts cropped from a 12-panel source sheet. **They do not have verified coastlines, and the generator introduced excessive castles and churches.** Do not claim historical fidelity around 1180 CE or put these directly on the main map. White/checkerboard background extraction requires alpha cleanup. The JSON records hashes and explicitly disables placement. Use as draft painting references before a geography-specific repaint.
