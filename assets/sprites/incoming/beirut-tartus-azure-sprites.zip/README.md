# Crusader Map — Azure coastal sprite wash

Beirut and Tartus: transparent RGBA sprites, 1096–1600 atlas scope. Only blue/cyan water hues were selectively washed toward azure; source compositions preserved. Preview-placement assets pending shoreline and print QA.
