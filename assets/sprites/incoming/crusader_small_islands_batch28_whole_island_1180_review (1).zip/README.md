# Crusader Map — Batch 28 (1180 whole-island review)

**Four independent RGBA island sprites:** Rhodes, Chios, Lesbos, and Corfu.

The painted settlements are deliberately exaggerated for readability. Their claimed island silhouettes and geographic orientation are *illustrative*, not precise coastline-aligned imagery. North-up, camera from south looking north is intended, but visual confirmation is still needed.

## Important QA constraints
- Source was RGB with a near-white backing (not genuine transparency). Alpha was reconstructed automatically. Review edges at print resolution, especially white buildings and surf.
- Period is circa 1180. Exclude later Hospitaller Palace and expanded Rhodes fortifications; Genoese Chios and later Mytilene Gattilusio works; Venetian Corfu bastions.
- These are **provisional alternatives**, not approved map replacements. Do not enable automatic placement or overwrite existing city sprites without individual map/coastline QA.
- `render_bbox_wgs84` in the manifest is the existing *island* bbox for reference, not a verified fit for the painted cutout. Use atlas-aligned geometry for a final build.
- Original source image and dark-background QA preview are included.
- Separate ZIP parts contain only the individual sprites plus metadata/checksums.
