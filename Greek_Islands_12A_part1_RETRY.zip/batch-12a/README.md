# Greek Islands Batch 12A — six new concepts

Keros, Farmakonisi, Alimia, Gyali, Ro, Strongyli. Six transparent RGBA PNGs, individually labelled, ready for sprite intake. **Concept-only**: coordinate, coastline, historic construction and alpha-fringe validation still pending. South-oblique painterly style. Do not automatically replace registered coastlines.
