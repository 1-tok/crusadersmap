# Crusader Coastal Cities — Historical Redo Batch 5

Four individually separated transparent RGBA sprites for review: Chastel Pèlerin/Atlit, Île de Graye, Alexandria, Damietta.

**Not approved for production or placement.** Match coast, camera view and 1180-specific buildings before promotion. Alexandria and Damietta must have Crusader flags removed or corrected. Île de Graye is an illustrative fortress candidate, not an authenticated reconstruction. Chastel Pèlerin follows the project-authorized alternate chronology portraying a completed fort in 1180.

All files include SHA256 values in `manifest.json`. Original sheet is preserved.
