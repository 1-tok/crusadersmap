# Crusader Map — Whole-island sprite review Batch 23

**Era:** approximately 1180 CE. **Status:** PROVISIONAL ART ONLY; not approved for map placement, georegistration, or print.

Four separate RGBA sprite paintings: Koufonisia (Ano + Kato as one multi-island composition), Chalki/Halki, Lipsi, and Kastellorizo/Megisti. Their settlements are deliberately enlarged while each island silhouette is shown as a whole; view intended from the south looking north.

These are upgraded alternatives to existing `data/sprites/greek-islands/batch-03` candidates. Existing artwork must not be deleted or overwritten; placement must use a single active sprite for each site after geographic and historical review.

**Transparency:** original generated sheet was RGB on an off-white background, despite an initial transparent appearance. A soft edge key was applied and each island was cut out as RGBA. Fine edge matte/halo and print tests remain unresolved; see `alpha_preview_dark.jpg`.

**History:** Exclude the post-1306 Hospitaller fortifications of Kastellorizo and 14th-century Chalki castle; Lipsi was Byzantine and under Patmos monastic grants by the late 11th century; Koufonisia contains Roman/early Byzantine remains but its 1180 settlement layout is uncertain. No building positions have been verified archaeologically.

**Geographic QA:** stylized island outlines; source artwork is not georeferenced. `placement.enabled=false`, `auto_place=false`, and `render_bbox_wgs84=null`. Candidate coordinates are island-area anchors from the project manifest, *not* validated image extents. Check Kastellorizo in particular against the inset boundary.

Contains source RGB sheet, per-island PNGs, a JSON manifest, alpha preview, and SHA256 checksums.
