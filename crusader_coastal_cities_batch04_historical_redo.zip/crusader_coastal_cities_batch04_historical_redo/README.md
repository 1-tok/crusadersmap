# Crusader coastal cities — historical redo batch 04

Individual PNG candidates: Ruad/Arwad, Jableh, Latakia, Baniyas.

These are four quadrant cutouts of the generated source sheet, stored as RGBA with genuine alpha; no artificial background removal was necessary. All assets are **provisional review only**. Historical details, depiction date, exact geographic north-facing viewpoint, shoreline orientation and alpha fringes require QA. Do not automatically overwrite existing registered sprites.

Special warning: Ruad is an offshore island. Its 1180 fortifications and heraldry should not be assumed to reflect the later Templar occupation. Baniyas waterfall scenery is unverified.
