# Crusader Map — Batch 24 whole-island art review (circa 1180)

**Subjects:** Aegina, Salamis (Attica, not ancient Salamis on Cyprus), Poros (Kalavria and Sferia), Hydra.

Each PNG is an independent painted island cutout with enlarged principal features for the Crusader Map Aegean inset. The source is an RGB image with a faint checkerboard backdrop: PNG alpha has been reconstructed programmatically, and a dark preview is provided. Fine halos, coastal contours, camera orientation and print resolution still require manual QA.

## Historical constraints

- **Aegina:** Byzantine village and church, Aphaia sanctuary as damaged ancient remains; no later or modern port buildings.
- **Salamis (Attica):** modest dispersed medieval rural settlement and Byzantine churches; do not confuse with the archaeological site Salamis in Cyprus.
- **Poros:** likely sparsely inhabited or largely uninhabited during the Middle Ages. Kalavria forest, Sanctuary of Poseidon ruins and small Sferia islet are shown; large modern town omitted.
- **Hydra:** sparse settlements and landing coves rather than the large merchant port and mansions of later centuries.

**Placement hold:** These are additional review alternatives to existing `data/sprites/greek-islands/batch-03` provisional art. Existing assets should not be overwritten; no automatic map placement is authorized. The anchors in `placement_manifest.json` are hints only, not approved bounding boxes. Whole-island silhouettes are illustrative, not georeferenced.

References: https://poros.gr/history.html ; https://www.visitporos.com/poros-general-info-en.html ; Byzantine monuments on Salamis (academic literature).
