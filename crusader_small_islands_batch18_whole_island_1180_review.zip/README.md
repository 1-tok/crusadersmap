# Crusader Map — Batch 18 | Whole-Island Sprites (1180 Review)

Four separate whole-island RGBA sprites: **Santorini, Kos, Leros and Patmos**. Principal settlements are intentionally enlarged at atlas scale. The camera convention is an elevated view from geographic south, looking north, but camera and coastline registration remain unverified.

## Placement and QA

- **PROVISIONAL FOR MAP REVIEW ONLY**; not print-approved, not committed to GitHub, not placed on the composite.
- The source image was RGB with a baked pale checkerboard. Transparency is **reconstructed** by color masking and connected-component isolation, with small white image holes filled and soft edges; review all shoreline edges for halos.
- A separate source-image file and dark-background QA preview are included. Each PNG excludes other islands in the sheet.
- These are **full-island alternatives**, not substitutes for historical place geometries. Match their coastlines to existing geographic boundaries; do not simply overwrite the coastline raster.
- When whole-island sprite is placed, suppress earlier independent city art on that island to avoid duplication.
- Santorini's 1180 caldera should show the Thira/Thirasia rims with ancient volcanic remnants, **not Nea Kameni**, which appeared from 1707.
- Kos, Leros: exclude post-1180 Hospitaller construction; Patmos: emphasize the monastery founded in 1088 while avoiding later additions.

## Historical sources

- Smithsonian Global Volcanism Program (Santorini): https://volcano.si.edu/volcano.cfm?vn=212040
- UNESCO monastery of St John, Patmos: https://whc.unesco.org/en/list/942

## Files

- `placement_manifest.json`: coordinates, checksums, dimensions and outstanding QA.
- `SHA256SUMS.txt`: SHA-256 hashes for image files and manifest.
- `alpha_preview_dark.jpg`: visual check on dark background.
- `source_sheet_rgb_checkerboard.png`: original image with baked checkerboard.
