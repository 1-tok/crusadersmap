# Crusader Map — Batch 12: Aegean coastal cities (1180 review)

Four separate transparent PNG concepts: **Kos, Naxos, Mytilene and Patras**. Original RGBA sheet and dark-background transparency preview included.

**Top-left:** Kos / Lango — Byzantine-era small port, east/north water. Avoid Hospitaller castle constructed later.

**Top-right:** Naxos / Naxie — western sea and Byzantine village. Do not include the Venetian Kastro of 1207.

**Bottom-left:** Mytilene — Byzantine fortress and eastern harbor. Exclude major Genoese Gattilusio building phases after 1355.

**Bottom-right:** Patras — Byzantine hill castle and lower port town with Gulf of Patras to the north. No Frankish defenses or heraldry after 1205.

## Technical QA

- RGBA source sheet with actual alpha; no baked checkerboard extraction required. Removed nearly transparent generator haze below alpha 9.
- Four independent quadrant crops. Original untouched source supplied for provenance.
- Check alpha_preview_dark.jpg for halos; native resolution is insufficient for automatic 300dpi print approval.
- Camera **intended** south looking north. Exact projection, coast matching, history, transparency fringe, and placement remain **unverified**.
- This is **not a production approval**; keep older active sprites until reviewed.

## Coordinates (reuse existing repo gazetteer)

Kos: 27.29E,36.89N; Naxos: 25.38E,37.10N; Mytilene: 26.55E,39.10N; Patras: 21.73E,38.25N.

## Historical references

- Naxos Venetian Kastro, founded 1207: Greek Ephorate of Antiquities of the Cyclades https://cyclades.culture.gov.gr/en/location/byzantine-naxos/
- Mytilene castle: Hellenic Heritage https://www.hh.gr/en/destinations/mytilene-castle/
- Patras Byzantine castle: Greek Ministry of Culture https://castleroute.culture.gov.gr/en/patras/
- Kos Byzantine and later Hospitaller phases: https://kos.gr/historical-monuments-and-museums/castle-of-kefalos
