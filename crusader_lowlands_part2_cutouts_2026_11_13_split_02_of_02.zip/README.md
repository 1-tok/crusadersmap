# Crusader Map lowland and coastal terrain — batch 2026-11-13

Contains five large original RGBA terrain sprites and four new multi-sprite sheets, split into 51 individual candidate RGBA cutouts (3×4, 3×4, 3×5, 3×4).

**Not placement-approved.** The crop grid was applied mechanically. Inspect sheet boundaries for cut art; the transparent edges, water placement, style and 300 DPI scale need QA. Do not place invented rivers or alter georeferenced coasts. Some coastal cutouts have water on a particular side and require geographic rotation/orientation check; do not automatically mirror artwork.

Target priority: Nile Delta irrigated lowlands, marshes and reeds; Aegean/Greece agricultural plain; Cyprus orchards and fields; Anatolian and Palestine/Levant coastal plains. Place below city/castle/road/label layers. Historical art for a multi-period 1095–1571 atlas, not certified reconstructions.

See placement_manifest.json for source, SHA-256 and individual identifiers.
