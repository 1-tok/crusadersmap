# Crusader Map — Batch 13, Aegean coastal replacements (1180 review)

Four individual RGBA PNG review candidates: Phocaea/Foça, Leros/Panteli, Lemnos/Myrina, and Corfu/Kerkyra. Source sprite sheet, dark-background QA preview, and SHA-256/placement manifest included.

**Status: provisional review only, not print-approved or committed to GitHub.** The image generator supplied an RGB sheet with a baked-in checkerboard; transparent alpha was reconstructed, with some possible halos and missing pale highlights. The dark-background preview is provided for visual inspection.

**Shared orientation:** elevated camera placed geographically south of each town, looking north, no mirroring. Coastlines follow the real site; west is image left and east image right.

**Distinct sites:** Phocaea has two natural harbors and a low promontory, avoiding later Genoese fortifications; Leros has an early Byzantine hilltop castle above the eastern harbor; Myrina has a fortified rocky headland between bays, without 1185 or Venetian additions; Corfu depicts its Byzantine promontory fortress without Venetian artillery bastions or the artificial sea moat.

**Map labels / anchors:** Foglie (26.75, 38.67); Lero (26.85, 37.15); Stalimene (25.07, 39.88); Corfou (19.92, 39.62). These are `places.py` map anchors, not precise city footprint placements.

**QA blockers:** historical architecture is interpretive, sea-side contact and south-view perspective require comparison against projected coastline, transparency edge cleanup and 300-dpi native pixel quality unverified. Do not place any more than one named-site variant at a time.
