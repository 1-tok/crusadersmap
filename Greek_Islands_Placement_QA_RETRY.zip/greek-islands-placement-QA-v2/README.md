# Crusader Map — Aegean placement QA v2
74 named candidate positions: 24 Batch 03 + 50 numbered newer islands (72–121); four Batch 05 unassigned concept drafts excluded. 47 older coastline-registered overlays remain unchanged.

This package adds the six new Batch 12B locator points (independently sourced), map image, transparent-concept contact sheet, per-island CSV and JSON review register, and a single sourced shoreline polygon for Pergousa. **Do not set `render_bbox_wgs84` from a point or polygon alone**: the artwork image must be registered pixel-to-coastline, and the whole image rectangle (including its margins) must be calculated. It has not been done here.

The raster is a candidate locator on modern reference geography, not a finished atlas painting composite. Batch 12B sprite art is in `crusader_greek_islands_batch12b_intake.zip`. Orientation is intended south-looking, not independently confirmed for each island. Background alpha extraction and print edges need inspection.

### Source references for added locations
- Nimos: https://mapcarta.com/12858478
- Sesklio: https://mapcarta.com/12853648/Map
- Gavdopoula: https://chronique.efa.gr/?id=38079&r=topo_public
- Kandelioussa: https://www.getty.edu/vow/TGNFullDisplay?subjectid=7229904
- Pergousa: https://www.getty.edu/vow/TGNFullDisplay?subjectid=7225893 and https://chronique.efa.gr/?id=39930&r=topo_public
- Pachia: https://mapcarta.com/12858058 (Nisyros Pachia; NOT the separate Cyclades island south of Anafi)
