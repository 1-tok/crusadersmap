# Crusader Coastal Cities — Historical Redo Batch 02

Acre, Tyre, Sidon, Beirut: separate cropped PNG candidates, with source sheet retained. **Review only.**

The images are historically inspired, not validated reconstructions. Tyre must be checked against its real peninsula/causeway; Sidon must not feature a 1228 sea castle in 1180. The generated source was RGB with white background, so transparent alpha was reconstructed and needs manual halo/white-structure QA. Check geographic camera and harbor side before replacing existing sprites.
