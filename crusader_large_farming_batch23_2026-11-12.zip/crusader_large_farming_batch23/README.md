# Batch 23 — large farming and lowland terrain

Four large independent RGBA sprites for geographic 1180 review, **not approved for final print**. Clip to landcover and avoid rivers/coasts; preserve map site and label layers. No coordinates assigned until gaps are confirmed in full map render.
