# Crusader Map — Batch 16: whole-island Aegean sprites (1180 review)

Four independent transparent RGBA PNGs: **Syros, Samos, Ikaria, Andros**. Each depicts the **entire island** with its principal settlement deliberately enlarged for map readability. Elevated view from geographic south toward north. The PNGs are standalone sprites; the source sheet and dark-background alpha preview are included.

## QA and use

- **Status: provisional review only.** No GitHub upload, merge, final map placement, or print approval is implied.
- Native RGBA transparency was preserved. Connected-component segmentation was used to isolate the four island silhouettes; minor stray fragments were removed.
- **Not precise cartographic geometry:** coastal contours, harbor bends, road layouts, and landmark positions must be registered to the actual Aegean inset before placement.
- Island anchor lon/lat in the manifest are the existing `places.py` ISLES centers, **not city coordinates**.
- Overlays should replace existing individual island decorations; avoid painting city sprites twice. Keep the exaggerated settlement on the same island as its anchor.
- Historical checks: Syros has early Byzantine occupation, but its familiar medieval hill settlement took much of its character in the 13th century; avoid modern Ermoupoli. Andros prospered with silk and Byzantine churches during the 11th–12th centuries, but do not add Kato Kastro (built after 1207). Ikaria favored defensible inland refuges. Samos retained Byzantine churches and classical ruins; do not depict later Genoese or Ottoman works.
- The image generator's sheet touches the top/bottom margins at two islands; verify cropped edges at 300 dpi.

**Sources for period checks:**
https://cyclades.culture.gov.gr/en/location/byzantine-syros/
https://cyclades.culture.gov.gr/en/location/andros/
https://www.visitikaria.gr/en/ikaria/history
https://whc.unesco.org/en/list/595

File hashes and actual dimensions are in `placement_manifest.json`.
