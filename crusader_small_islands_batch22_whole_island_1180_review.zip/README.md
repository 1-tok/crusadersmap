# Crusader Map — Batch 22: Lesser Cyclades whole-island candidates (1180)

**Subjects:** Sikinos, Donousa, Irakleia, Schinoussa.

Four individual cropped RGBA PNGs, showing the full island with a deliberately enlarged settlement. Intended elevated camera from south looking north; north-up projection and geographic coastlines **not independently verified**.

**Status: PROVISIONAL_REVIEW — NOT APPROVED, NOT AUTO-PLACED.**

The original source artwork was RGB with nearly white background, not native alpha. Transparency was reconstructed programmatically; fine anti-aliased edges and light architectural highlights may need manual cleanup before print.

The repository already has provisional Batch-03 candidates for all four islands. Do not overwrite them: compare outlines and historical chronology first. Candidate anchor coordinates are approximate, not registration bounding boxes.

Historical cautions:
- Sikinos: depict the Roman Episkopi monument repurposed as Byzantine church; a large fortified city would be inaccurate.
- Donousa: the fortified Vathy Limenari site is *Geometric-period* archaeology, not proof of an active fortress in 1180.
- Irakleia: very small interpreted medieval community; no asserted historical fortress.
- Schinoussa: late-antique basilica and settlement at Cape Portokali were abandoned by about the mid-7th century: ruins, not a functioning major basilica in 1180.

Reference context: Hellenic Ministry of Culture Ephorate of Antiquities of the Cyclades, profiles of Episkopi (Sikinos), Donousa, Schoinoussa.

Archive parts include README, manifest and SHA-256 list. Full package additionally contains source sheet and dark QA preview.
