Batch 37 Canaan Coastal Underlays

Four artwork concepts for Acre/Carmel, Sharon Plain and Gaza lowland. No coordinates assigned or map placement claimed. Place under settlements and landmarks, clipped to land mask; check transparency/edge halo before use.
