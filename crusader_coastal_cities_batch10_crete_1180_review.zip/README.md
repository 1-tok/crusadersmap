# Crusader Map — Coastal Batch 10: Crete (~1180)

Four separate review-only RGBA cutouts: Candia/Chandax (Heraklion), Chania/Kydonia, Rethymno, Sitia. Also includes original RGB source sheet, placement manifest and SHA-256 checksums.

**Critical:** Although this sheet appears checkerboard-transparent, the generator returned an **RGB image with checkerboard baked in**. Alpha was constructed by background masking. Source artwork is 1536 x 1024; each sprite is cropped from one quadrant, so native resolution is limited and **not 300 dpi print ready**. Expect edge fringes in pale water and masonry; inspect on dark and light backgrounds. No sprites are committed to the GitHub repo or approved for production placement.

### Geographic camera and history
- View: elevated observer due south looking north; image-left = west, image-right = east. All four are on the **north coast of Crete**; sea belongs **behind** the settlements, not generally left.
- Chandax: existing map anchor 25.13 E, 35.34 N; rebuilt Byzantine city and harbor, not Venetian 16th-century bastion walls.
- Chania: existing anchor 24.02 E, 35.51 N; modest Byzantine Kastelli hill settlement, not later Venetian defenses/lighthouse.
- Rethymno: existing anchor 24.48 E, 35.37 N; do not depict the Venetian Fortezza begun 1573.
- Sitia: proposed 26.11 E, 35.21 N; **not present as a named site in active places.py**. Avoid the Venetian Kazarma.

### QA gates prior to placement
1. Check alpha fringe and coastline/water masking at final print zoom.
2. Compare each city with actual shoreline masks and anchor, particularly northern behind-city sea and Sitia bay.
3. Validate era-specific architecture and building scale; do not imply these paintings are archaeological reconstructions.
4. Keep older variants; single primary candidate per named site.
5. Review in geographic inset, not on a disconnected sprite grid.

Historical sources consulted: Municipality of Heraklion (Heraklion through the Centuries), Chania Kastelli history, Municipality of Rethymno (Fortezza), Hellenic Heritage (Sitia Kazarma), UNESCO late medieval fortifications in Greece.
