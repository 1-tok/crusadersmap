# Crusader Coastal Cities — Historical Redo Batch 03

Four independent RGBA cutouts prepared for **review only**: Byblos/Gibelet, Batroun/Botron, Tripoli/al-Mina, and Tartus/Tortosa. The original 2x2 source sheet is also included.

## Site distinctions
- **Byblos**: castle above compact ancient town and small port; west/left water.
- **Batroun**: small seafront town on rocky headland with wine-growing hinterland; no giant citadel city.
- **Tripoli**: medieval maritime al-Mina site, not later inland Mamluk city.
- **Tartus**: Templar castle at northern seafront and separate town/cathedral; avoid importing later 13th-century additions.

## QA holds
- Rendered sheet was RGB with baked checkerboard, despite requested native transparency. Alpha has been reconstructed; inspect halos, edge color spills and holes before atlas use.
- Camera must be evaluated as truly south looking north in map placement; sea west/left is necessary but not sufficient.
- No official site geometry or historic footprints validated in this extraction.
- This is **not production/print-approved** and has not been committed to GitHub.
