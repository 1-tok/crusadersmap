# Greek Islands — Batch 07

Six transparent concept sprites: Agathonisi, Pserimos, Telendos, Meganisi, Kinaros and Levitha.

These are **illustrative drafts**, not verified island shapes or circa-1180 architectural reconstructions. Castles, churches, piers and settlement patterns may be anachronistic. Red/blue fringe and sprite cropping around neighboring panels require QA.

The original full sheet is preserved for recropping. Placement is disabled in the JSON; render bounding boxes must be established against geographic island polygons before any review-map overlay.
