# Crusader Map — Batch 15: Whole-Island Aegean Sprites (c. 1180)

Four individual 32-bit RGBA PNG sprites: Paros / Paroikia, Skyros / Chora, Skopelos / Chora, Tenedos / Bozcaada.

**User-specific scale rule:** Each scene includes the **entire island** within a single sprite. The principal settlement is intentionally oversized (approximately 2–3 times its accurate proportion) to remain visible on the full printed map. The island is the geographic anchor; do not paste an additional generic city on top. Camera is intended due south looking north. The outlines are **artistic approximations** and must be checked against true GIS shore geometry.

## Files

- Individual `*_review_v1.png` = cropped RGBA assets (checkerboard removed programmatically)
- `source_sheet_rgb_checkerboard.png` = unmodified 2x2 sheet
- `alpha_preview_dark.jpg` = independent cutouts on dark background, for fringe review
- `placement_manifest.json` = site IDs, existing ISLES anchors, camera, water-side, QA state, checksums

## Suggested placement & historical notes

| Name | Island anchor (lon,lat) | Sea-side relationship | Key identity |
|---|---|---|---|
| Paros | (25.18,37.05) | Town on west; sea left | Katapoliani basilica and Byzantine Paroikia acropolis; exclude Venetian castle expansion |
| Skyros | (24.55,38.90) | Chora eastern side; sea right | Byzantine hilltop fortification and irregular wooded island |
| Skopelos | (23.65,39.15) | Chora northeast; sea upper right | Earlier Byzantine acropolis; exclude later Venetian fortifications |
| Tenedos | (26.03,39.83) | Harbor east/northeast; sea right | Modest Byzantine port and island vineyards; exclude later rebuilt castle |

## QA / approval

Approved as *review candidates only*, not production placement or print. RGB checkerboard was extracted into alpha, so check colored fringe along vegetation and rocky shores. The design preserves map readability but not metric architectural scale. Full-island geometry and coastline registration not verified. Approximate historical and architectural portrayal, **not a documented reconstruction**. Do not commit over existing sprites; retain alternate variants and require period/camera QA.

**Repo integration suggestion:** add each to island underlay layer (above sea below labels), suppress repeated island decoration under each cutout, and ensure actual island landmask fully covered. Test each island after placement.

### Historical/source pointers

- Paros: https://cyclades.culture.gov.gr/en/location/byzantine-paros/
- Skyros: https://www.medievalroutes.gr/en/
- Skopelos: https://visit.skopelos.gr/en/attractions/castle-skopelos
- Tenedos island outline: https://www.researchgate.net/figure/Map-of-Bozcaada-Tenedos_fig8_319881541
