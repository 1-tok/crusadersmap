# Crusader Map — Batch 11: Aegean fallback replacements (~1180)

Four separate RGBA review images: Gallipoli / Gelibolu, Petronion / Bodrum, Patmos St John, Mount Athos Great Lavra.  Existing active map has generic fallback images for each; **these are proposed candidates only, not committed or promoted**.

## History and visual specification
- Gallipoli: Byzantine Dardanelles port town rather than late Ottoman scene. Straits shore must be matched against the Aegean inset.
- Petronion / Halicarnassus: **exclude** the later Hospitaller Castle of St Peter begun after 1400. Scene includes ancient remains and modest Byzantine port settlement.
- Patmos: monastery of St John established 1088, with modest surrounding settlement; later Chora buildings should not be retrojected into 1180.
- Mount Athos / Great Lavra: established 963; depict early Byzantine monastery below forested Mount Athos, avoid later complex architecture.

## Technical status
Source image was **RGB with baked-in checkerboard**, not actual PNG transparency. Each quadrant was segmented by color and converted to RGBA. Inspect the included alpha_preview_dark.jpg; pale edges, masonry and foam require manual refinement. Art is small relative to 300-dpi print scale. Intended camera is due south looking north but is **not geographically certified**. Verify correct local sea side and shoreline masks before replacement.

Review-only; no placement, historical, print, or production approval. Keep prior variants and original image in review gallery.

Source historical references: UNESCO Patmos monastery, founded 1088; Great Lavra 963 (Mount Athos); castle of St Peter on Bodrum begun in the early 1400s (Heslop 2014).
