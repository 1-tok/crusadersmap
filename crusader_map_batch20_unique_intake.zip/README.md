# Batch 20 — Unique rural craft assets

Two concept cutouts: tannery/dye yard and rural smithy. All other images in earlier sheets repeat past subjects or lack defensible new identities. Upload this ZIP to assets/sprites/incoming on main. Historical identity and positions have not been validated. Edge reconstruction is provisional. Original sheet is preserved in the archive under originals/.
