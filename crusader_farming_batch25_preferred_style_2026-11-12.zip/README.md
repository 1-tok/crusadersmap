# Batch 25 — preferred large farmland style

Four individual ~1774×887 RGBA paintings, provisional for geographic review. The two rejected Batch 24 paintings are excluded. Not uploaded to GitHub; not print approved. All need edge-fringe QA, and 25_02/25_03 show noticeable halo/background concerns.
