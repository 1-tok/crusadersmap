# Crusader Map — Batch 08: Aegean sites (c. 1180)

Four individual **original-alpha RGBA** review PNGs plus their unmodified source sheet.

**Order on source sheet:** top left Rhodes; top right Chios; bottom left Smyrna; bottom right Ephesus/Ayasoluk.

## Important QA holds

- Keep camera south looking north; coastal orientation is **not independently verified**.
- Rhodes must be Byzantine (not later Hospitaller), Chios pre-Genoese, Smyrna pre-Hospitaller; avoid later fortifications.
- Ephesus is placed as medieval **Ayasoluk**, on an inland hill near former classical Ephesus, not as an active Roman seaport.
- All four are provisional review cutouts: do not auto-promote into the final sprite selector or overwrite primary originals.
- The artwork has actual transparency; no destructive checkerboard removal was needed. Some fringe/color QA is still required.
- Pixel dimensions are much smaller than print masters; **not print-approved**.

See `placement_manifest.json` for historical map site anchors, checksums, orientations, and individual hold reasons.
