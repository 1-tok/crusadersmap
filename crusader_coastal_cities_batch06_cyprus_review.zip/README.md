# Crusader Map — Cyprus coastal cities, batch 06

Four separately cropped review-only RGBA PNGs: Famagusta, Kyrenia, Limassol, Paphos. Source sheet retained.

**CAUTION:** Source sheet is an RGB checkerboard image. Transparency is reconstructed and may contain light halos, cutaway details or checker texture within paintings. No manual pixel-edge QA, strict north camera certification or historical architecture approval.

Sea placement by site: Famagusta east/right, Kyrenia north/background, Limassol south/foreground, Paphos southwest/front-left. These are geographic intentions, not confirmed map placement.

No sprite registry changes or GitHub upload were made.
