# Crusader coastal cities — Batch 4 (review only)

Four separate transparent PNG candidate illustrations, cropped from an AI-generated 2×2 source sheet.

- Top left: Ruad/Arwad — **HOLD**: depicts a mainland-style harbor, not the offshore island geography; needs repaint.
- Top right: Jableh — provisional, south-facing orientation and shoreline to be checked.
- Bottom left: Latakia — provisional, check scale and actual coastline.
- Bottom right: Baniyas (Syrian coast) — provisional; do not confuse with inland Banias near Mount Hermon.

Background transparency was extracted programmatically from a bright checkerboard-like source; some halos or pale features may need refinement. Banners and historical architecture are illustrative and not historically authenticated. All sprites remain unapproved for production or geographic placement. No GitHub changes were made.
