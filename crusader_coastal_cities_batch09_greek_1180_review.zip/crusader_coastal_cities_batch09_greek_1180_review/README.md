# Crusader Map — Greek coastal cities, Batch 09 (1180 review)

Four visually distinct, individual RGBA sprites extracted from a single generated 2x2 sheet, keeping actual alpha transparency. This is review art, **not validated map placement or 300-dpi print approval**.

| Subject | Repo map name | Approx. lon/lat | Geography and chronology |
|---|---|---|---|
| Methoni | Modon | 21.71, 36.81 | Byzantine port and smaller pre-Venetian defense; omit post-1209 Venetian walls and Bourtzi |
| Koroni | Coron | 21.96, 36.80 | Original Byzantine hilltop fort and small port; avoid Venetian eastern enclosure and later bastions |
| Monemvasia | Monemvasie | 23.04, 36.69 | Byzantine Upper and Lower Town, 12th-c Hodegetria/Agia Sophia, no later Venetian fabric |
| Nafpaktos | Lepanto | 21.83, 38.39 | Byzantine upper hilltop citadel; do not add Venetian 15th-c waterfront ring walls or gun bastions |

## Placement and QA

- Camera: from south looking north, west visually left and east right; imagery still needs GIS-shoreline orientation check.
- Methoni: flat long peninsula; never use the later Venetian Bourtzi island tower or gun-era defenses in 1180.
- Koroni: Byzantine core, hillside castle and smaller harbor, not a later Venetian coastal enceinte.
- Monemvasia: large sheer offshore rock and west approach, with southeast Lower Town; no invented inland city or generic harbor.
- Nafpaktos: upper Byzantine hilltop stronghold over open coastal town; the famous enclosed Venetian fortified harbor is later.
- No city banners or 13th–16th-century regime flags are intended. Visual and era details remain provisional.
- Provenance: source_sheet_rgba.png is included for editing and image provenance.
- Next step: compare crop against repo existing primary at the true site anchor, render using coastline masks, audit water overlap and at-print-size legibility.

## Reference material used for historical constraints

- Hellenic Ministry of Culture / Ephorate of Antiquities, Methoni and Koroni castle entries.
- Greek Ministry of Culture, Nafpaktos historical castle entry (castleroute.culture.gov.gr).
- Monemvasia Greek tourism and local history pages for Upper and Lower Town.
