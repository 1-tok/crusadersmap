# Coastal City Historical Redo — Batch 01

Four separate provisional review sprites: Gaza, Ascalon, Jaffa, Caesarea. Repaint uses distinct architecture and topography. **Not approved for geographic placement or printing.** Alpha reconstruction from baked checkerboard requires manual pixel-edge review. The 1180 site-specific historical fabric and shoreline geometry are not certified. Original source sheet included.
