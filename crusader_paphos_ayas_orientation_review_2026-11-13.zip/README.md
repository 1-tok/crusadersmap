# Crusader Map — Paphos and Ayas water-orientation candidates

Both locations already have named sprite artwork in GitHub. These are **review-only alternative variants**, never generic replacements or new city entries.

- `sprites/paphos-1180-south-southwest-harbor-review-v1.png`: one image of Paphos, south-looking-north. Mediterranean on left/front; Saranta Kolones north of port. White-background RGB source was converted to RGBA; manual edge cleanup, architecture and print proof required. Some exposed inner columns may be anachronistic/interpretive.
- `sprites/ayas-laiazzo-c1300-east-gulf-review-v1.png`: crop of the Ayas-specific quadrant of a four-scene transparent concept image. Gulf on right/east, mainland castle and offshore castle separate. Cross-period c.1300 only. Exact land castle, island position, ownership and banners remain historical QA holds.

Both sprites have alpha 0–255 with transparent margins, are independent PNG files, and keep originals intact in GitHub. `review/` contains checker-background inspection aids, not map sprites. Source generation imagery is not packaged to avoid mistaken placement of composite sheets. No GitHub changes made.

## Placement QA gate
Map north-up orientation → south-facing camera → period filter → shore and harbor clipping → alpha-edge check → landmark research → actual map-scale print proof → manual approval.
