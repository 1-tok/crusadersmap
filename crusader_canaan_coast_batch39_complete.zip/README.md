# Batch 39 — Canaan Coastal Review Artwork

Four individual PNG overlays. All contain painted coastlines or waterways: **not approved for placement** until exact coast/river masks are checked. Source paintings preserved.
